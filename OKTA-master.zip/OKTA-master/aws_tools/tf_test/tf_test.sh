#!/bin/bash
!/bin/bash
set -xe

FAILURE=false
TERRAFORM_ACTION_WARNINGS=false

# Terraform fmt default rules: https://www.terraform.io/docs/commands/fmt.html
# Test return code for failure
function error_check() {
  if [ $1 -gt 0 ]; then
    FAILURE=true
    echo "TEST: $2 , STATUS: FAIL"
  else
    echo "TEST: $2 , STATUS: PASS"
  fi
}

# Running terraform fmt for DataVip directory
echo "Checking terraform fmt results..."
/usr/local/bin/terraform fmt -list=true -check
error_check $? "terraform FMT Check"

if [ "$FAILURE" == true ]; then
  echo "FAIL: TEST COMPLETED WITH FAILURES."
  exit 1
else
  echo "SUCCESS: TESTS COMPLETED WITHOUT FAILURES."
  exit 0
fi
