# okta-test
This repo is used to store terraform templates used to configure OKTA tenant via [Articulate okta provider](https://github.com/articulate/terraform-provider-okta).
Here is the link to terraform okta provider [documentation](https://www.terraform.io/docs/providers/okta/index.html)
## Requirements
* golang 1.12
* terraform 0.12.16
* compiling terraform-provider okta
* setting env var `TF_VAR_okta_api_token` with API token allowing interaction with OKTA
